/**
 * shrink.ts — the `mulligan_shrink` agent-callable tool (spec/05 §2; spec/04 §4; spec/06 §5).
 *
 * SECOND of the four Mulligan agent-callable tools (P1.M5.T2.S1). It is the sole writer of the
 * `mulligan:shrink` marker (soft substitution). When a past tool result (or message) is too bloated
 * to keep carrying verbatim but too useful to delete, the agent calls this tool with a matcher-based
 * `target` and a compact `replacement`. The tool validates, does a best-effort read-only match for
 * immediate yes/no feedback, persists the shrink marker, and returns the feedback text. The
 * AUTHORITATIVE substitution happens in the `context` filter on the NEXT inference (spec/06 §5) — this
 * tool only records the spec (D7 — record a spec, not content).
 *
 * DESIGN (read the gotchas + the PRP):
 * - Thin, typebox-schema'd, validation-owning adapter on top of `appendShrinkMarker` (src/markers.ts,
 *   P1.M4.T1.S1 — ALREADY shipped & unit-tested). This tool does NOT reimplement `pi.appendEntry`, the
 *   envelope/seq/leaf capture, or matching (`resolveShrinkTarget`, src/transforms.ts — P1.M3.T4.S2) —
 *   it delegates persistence to the marker wrapper and resolution to the pure resolver.
 * - The TOOL owns: config gate (config.shrink.enabled — E14), replacement-non-empty validation,
 *   structural-target-validity validation (the ONE design judgment — refuse ONLY a discriminator that
 *   can provably never match; GOTCHA #7), the best-effort yes/no match (advisory, never blocks —
 *   GOTCHA #6), the persisted payload, and the success/refusal text.
 * - The tool is WRITE-ONLY w.r.t. the message list: it NEVER receives/transforms `event.messages`
 *   (it is not the context event). It builds a SNAPSHOT via
 *   `ctx.sessionManager.buildContextEntries().flatMap(sessionEntryToContextMessages)` for the ADVISORY
 *   match. If that snapshot/resolution fails, it falls back to matched:false + STILL persists (the
 *   marker spec is what matters; E13/E8 — never let an advisory computation block a legitimate shrink).
 * - CRITICAL GOTCHA #1 (vs the sibling rewind tool): NO cast, NO note, NO extras. ShrinkMarkerInput in
 *   src/markers.ts (FROZEN, spec/04 §4) is EXACTLY `{ target, replacement, reason? }` — there is NO
 *   field gap (unlike rewind's checkpoint gotcha). The tool builds
 *   `{ target, replacement, reason }` and passes it DIRECTLY to appendShrinkMarker — NO cast, NO extra
 *   field, NO leaveNote call. Do NOT cargo-cult rewind's leaveNote/renderNote/validateNote/ledger
 *   machinery — shrink has none of it.
 * - Shared tool convention (spec/05 "Shared tool conventions"): the execute body is fail-open to text —
 *   it NEVER throws (E13). The whole body is wrapped in ONE try/catch → text result on any exception.
 * - CRITICAL GOTCHA #4: every `AgentToolResult<T>` return path includes a `details` field (spec/05 §2's
 *   `{ content:[...] }`-only return shape is a SIMPLIFICATION — `details` is REQUIRED by the Pi type;
 *   this file is strict-typechecked by tsconfig). We use a small structured object (`{ matched?,
 *   markerId? }`) surfaced to logs/audit/UI on every path.
 * - `pi` (ExtensionAPI) is NOT passed to execute() — it is captured via the `makeShrinkTool(pi)`
 *   factory closure (the checkpoint.ts precedent; no module-scoped mutable state). index.ts
 *   (P1.M7.T1.S1) does `pi.registerTool(makeShrinkTool(pi))`.
 *
 * This item does NOT modify src/index.ts (wiring is P1.M7.T1.S1), src/filter.ts (P1.M4.T2 runs in
 * parallel — this tool WRITES the markers the filter READS), or markers.ts/transforms.ts/config.ts
 * (frozen, consumed).
 */
import { Type } from "typebox";
import type { Static } from "typebox";
import {
  defineTool,
  sessionEntryToContextMessages,
  type AgentToolResult,
  type ExtensionAPI,
  type ExtensionContext,
  type SessionEntry,
  type ToolDefinition,
} from "@earendil-works/pi-coding-agent";
import { appendShrinkMarker } from "../markers.js"; // GOTCHA #9: .js extension (ESM/Bundler resolution); GOTCHA #1: NO cast
import type { ShrinkMarkerInput } from "../markers.js";
import { resolveShrinkTarget } from "../transforms.js"; // Pi-free (0 imports) — no circular dep
import type { ShrinkTarget } from "../transforms.js"; // structurally identical to markers.ts ShrinkTarget
import type { MessageLike } from "../transforms.js";
import { getConfig } from "../config.js"; // GOTCHA #10: read ONCE per execute

// ── Parameter schema (spec/05 §2 — Typebox, VERBATIM incl. the 3-arm target union + descriptions) ────

/**
 * ShrinkParams — the typebox parameter schema for `mulligan_shrink` (spec/05 §2, verbatim incl. every
 * field description — the LLM reads them). `Static<typeof ShrinkParams>` === `ShrinkMarkerInput` ===
 * `{ target: ShrinkTarget; replacement: string; reason?: string }` (the shared contract with the
 * filter — spec/04 §4). EXPORTED for tests + the index.ts wiring step.
 *
 * The `target` union is copied VERBATIM from spec/05 §2 (the three matcher arms + their descriptions):
 *   - by_tool_call_id         — unique; resolves to the toolResult with that toolCallId.
 *   - by_tool_name+occurrence — semantic; the last (default) or first toolResult with that toolName.
 *   - by_content_includes     — content-based; the first message (any role) whose text contains the substring.
 */
export const ShrinkParams = Type.Object({
  target: Type.Union(
    [
      Type.Object({ by_tool_call_id: Type.String({ description: "The toolCallId of the result to shrink." }) }),
      Type.Object({
        by_tool_name: Type.String({ description: "e.g. 'read', 'bash'" }),
        occurrence: Type.Union([Type.Literal("last"), Type.Literal("first")]),
      }),
      Type.Object({
        by_content_includes: Type.String({
          description: "Shrink the (first) message whose text contains this substring.",
        }),
      }),
    ],
    { description: "How to identify the message to shrink. Resolved live each turn (robust to compaction)." },
  ),
  replacement: Type.String({
    description:
      "The compact text that replaces the matched message's content. Make it a faithful summary — the model will treat it as ground truth from now on.",
  }),
  reason: Type.Optional(Type.String({ description: "Why (surfaced in audit). Optional." })),
});

/** ShrinkArgs — the inferred execute-time params type. EXPORTED for ergonomics/tests. */
export type ShrinkArgs = Static<typeof ShrinkParams>;

// ── The LLM-facing description string (spec/05 §5 — copy VERBATIM) ────────────

/**
 * SHRINK_DESC — the LLM-facing description (spec/05 §5 "Description strings", Mode A LLM-facing docs).
 * This string IS the tool's documentation. Copy verbatim — it drives LLM usage. (spec/05 §5 line 79.)
 */
export const SHRINK_DESC =
  "Replace a specific past tool result with a compact summary you provide, in your view, going forward. " +
  "Use when the call was fine but its output is too big to keep carrying. Unlike rewind, the call stays in " +
  "context (just with your summary as its result).";

// ── Result builders (always include `details` — CRITICAL GOTCHA #4) ──────────

/** ShrinkDetails — the structured `details` payload surfaced to logs/audit/UI. Present on every path. */
export interface ShrinkDetails {
  /** Best-effort "does the target match a message right now" result. true/false on the success path;
   *  omitted on refusal (no match attempted). Drives the "(Matched now: yes|no)" feedback + audit correlation. */
  matched?: boolean;
  /** The persisted marker's ENTRY id (appendShrinkMarker's return; null when append threw / no leaf). Success path. */
  markerId?: string | null;
}

/**
 * refusal — build a fail-open text result for a config-disabled / invalid-replacement /
 * structurally-impossible-target / unexpected-error case. ALWAYS includes `details` (CRITICAL GOTCHA #4).
 * The shared convention prefixes every refusal with "Mulligan: refused — <reason>." so the agent can
 * pattern-match a refusal regardless of the underlying reason (spec/08 E14 framing; checkpoint.ts +
 * rewind.ts precedent). `reason` is emitted WITHOUT a trailing period — the helper adds it.
 */
function refusal(reason: string): AgentToolResult<ShrinkDetails> {
  return {
    content: [{ type: "text", text: `Mulligan: refused — ${reason}.` }],
    details: {},
  };
}

/**
 * feedbackText — the TERSE success text (P1.M2.T1.S2): just the yes/no outcome, no prose. The full
 * replacement is NOT echoed here (it would bloat the tool result / context); instead the operator gets
 * a capped echo via `ctx.ui.notify` in step (5b) at zero context cost (the model never sees it). The
 * `(Matched: yes|no)` slot reflects the best-effort match from resolveTargetEntryId (advisory; never blocks).
 */
function feedbackText(matched: boolean): string {
  return `Mulligan: shrink recorded. Matched: ${matched ? "yes" : "no"}.`;
}

// ── pure validation + match helpers (module-private; never throw) ────────────

/**
 * cap — clamp a string to `max` chars for operator display, appending an ellipsis + total-length note
 * when truncated (P1.M2.T1.S2 operator echo). Defensive: returns `s` unchanged if it is not a string or is
 * already within the cap. Uses the U+2026 ellipsis (`…`) per spec/05 §2 step 5b formatting.
 */
function cap(s: string, max: number): string {
  if (typeof s !== "string" || s.length <= max) return s;
  return s.slice(0, max) + `…(${s.length} chars total)`;
}

/**
 * describeTarget — a short human-readable label for the shrink target (P1.M2.T1.S2 operator echo).
 * Defensive: returns "message" for a non-record target. Mirrors the three matcher arms from ShrinkParams.
 */
function describeTarget(target: ShrinkArgs["target"]): string {
  if (!target || typeof target !== "object") return "message";
  if ("by_tool_call_id" in target) return `tool call ${target.by_tool_call_id}`;
  if ("by_tool_name" in target) return `${target.by_tool_name} result`;
  if ("by_content_includes" in target)
    return `message containing "${target.by_content_includes.slice(0, 40)}"`;
  return "message";
}

/**
 * isNonEmpty — true for a non-blank string; false for a blank string or a non-string (defensive — never
 * throws). Used for the replacement AND the target discriminator (GOTCHA #7).
 */
function isNonEmpty(s: unknown): boolean {
  return typeof s === "string" && s.trim().length > 0;
}

/**
 * targetIsStructurallyValid — the "structurally impossible target" operationalization (GOTCHA #7). The
 * ONE design judgment in this tool: refuse ONLY when the target can NEVER match. A target is structurally
 * invalid when its present discriminator (by_tool_call_id / by_tool_name / by_content_includes — whichever
 * is a string) is EMPTY or WHITESPACE-ONLY after trim. Verified reasoning against resolveShrinkTarget
 * (transforms.ts) internals:
 *   - by_tool_call_id:"" / by_tool_name:"" → resolveShrinkTarget skips the arm (length>0 check) → null forever.
 *   - by_content_includes:"" → NO length check → degenerate match on the FIRST message (every string includes "").
 * Both are noise → refuse. A NON-EMPTY-but-currently-unmatched target is NOT refused (compaction-robust;
 * content may appear before a compaction settles — E8; the marker persists and the filter re-resolves it
 * each inference). Defensive (non-record target → false; never throws). occurrence is typebox-constrained to
 * "last"|"first"; resolveShrinkTarget defaults non-"first" to "last" → do NOT validate occurrence.
 */
function targetIsStructurallyValid(target: ShrinkArgs["target"] | undefined): boolean {
  if (!target || typeof target !== "object") return false; // non-record → no recognizable discriminator
  if ("by_tool_call_id" in target) return isNonEmpty(target.by_tool_call_id);
  if ("by_tool_name" in target) return isNonEmpty(target.by_tool_name);
  if ("by_content_includes" in target) return isNonEmpty(target.by_content_includes);
  return false; // no recognizable discriminator key
}

/**
 * entryIdAtMessageIndex — map a resolved MESSAGE index back to the STABLE ENTRY id of the entry that produced it
 * (mirrors captureHideEntryIds in rewind.ts, for a SINGLE index). Walks `entries` with a cursor using the SAME
 * `entries.flatMap(sessionEntryToContextMessages)` mapping that built `messages` (resolveTargetEntryId, below), so
 * entry `e` ↔ messages[cursor..cursor+yield) is EXACT BY CONSTRUCTION — no position math. Returns null on no-match /
 * a non-string/empty entry id (defensive). Called inside resolveTargetEntryId's try/catch → null on throw (E13).
 */
function entryIdAtMessageIndex(entries: SessionEntry[], index: number): string | null {
  if (!Array.isArray(entries) || typeof index !== "number" || !Number.isFinite(index) || index < 0) return null;
  let cursor = 0;
  for (const e of entries) {
    const y = sessionEntryToContextMessages(e).length; // typically 1 (message/custom_message/branch_summary)
    if (index < cursor + y) {
      const id = (e as { id?: unknown }).id; // SessionEntryBase.id is a stable string; guard rejects empty/non-string
      return typeof id === "string" && id.length > 0 ? id : null;
    }
    cursor += y;
  }
  return null;
}

/**
 * resolveTargetEntryId — the ADVISORY read-only match that ALSO captures the matched message's STABLE ENTRY id
 * (FINDING 3 fix; supersedes the old boolean bestEffortMatch). It builds a SNAPSHOT via
 * `ctx.sessionManager.buildContextEntries().flatMap(sessionEntryToContextMessages)` (NOT event.messages — the tool
 * is write-only w.r.t. messages), feeds it to the PURE resolver `resolveShrinkTarget` (transforms.ts), and — on a
 * match — maps the resolved MESSAGE index back to its ENTRY id via entryIdAtMessageIndex. Returns null on no-match.
 *
 * The captured ENTRY id becomes the marker's `pinnedEntryId`: at filter time applyShrink resolves it by IDENTITY
 * (resolvePinnedShrink) instead of re-resolving the live selector, so by_tool_name+last / by_content_includes can no
 * longer drift onto later messages as the session grows (the moving-target footgun). ADVISORY ONLY — a null return
 * STILL persists the marker (live-resolution path; E8) and NEVER gates persistence. Wrapped in try/catch → null
 * (a throwing buildContextEntries / sessionEntryToContextMessages must never block a legitimate shrink — E13). The
 * AUTHORITATIVE substitution happens in the filter on the next inference (D7).
 */
function resolveTargetEntryId(ctx: ExtensionContext, target: ShrinkArgs["target"]): string | null {
  try {
    const entries = ctx.sessionManager.buildContextEntries(); // GOTCHA #5: snapshot, compaction-aware
    // sessionEntryToContextMessages returns Pi's AgentMessage[]; transforms.ts MessageLike is a Pi-free
    // structural type — a real AgentMessage[] assigns in with NO cast (GOTCHA #5, api_verification.md §6.1/§6.3).
    const messages = entries.flatMap((e) => sessionEntryToContextMessages(e)) as unknown as MessageLike[];
    const i = resolveShrinkTarget(messages, target as ShrinkTarget); // PURE resolver (transforms.ts)
    if (i === null) return null;
    return entryIdAtMessageIndex(entries, i); // map message index → stable ENTRY id (null on misalignment)
  } catch {
    return null; // GOTCHA #6: never block a legitimate shrink on an advisory computation (E13)
  }
}

// ── execute (spec/05 §2 behavior; shared tool convention = never throws) ─────

/**
 * shrinkExecute — the tool body. Steps (spec/05 §2 steps 1–5):
 *   1. config (step 1; E14): getConfig() once; `config.shrink.enabled`? false → refuse "shrink is disabled".
 *   2. replacement (step 2): empty/whitespace-only after trim? → refuse "replacement must be non-empty".
 *   3. structural target (step 3 — the "structurally impossible" refusal; GOTCHA #7): the present
 *      discriminator empty after trim? → refuse "target discriminator must be non-empty". (A non-empty-but-
 *      currently-unmatched target is NOT refused — E8.)
 *   3/4. best-effort match (step 3 — the yes/no feedback; advisory, never blocks; GOTCHA #6): snapshot →
 *        resolveShrinkTarget → matched boolean. try/catch → false (belt-and-suspenders; bestEffortMatch
 *        already catches — E13).
 *   5. persist (step 4; GOTCHA #1 — NO cast, NO leaveNote): appendShrinkMarker(pi, ctx, {target,
 *      replacement, reason}) → markerId (the ENTRY id, or null).
 *   6. return (step 5): feedbackText(matched) + details:{ matched, markerId }.
 *
 * The WHOLE body is wrapped in ONE try/catch → refusal text on ANY exception (GOTCHA #5: never throw on
 * the tool hot path — E13). `pi` is captured by the `makeShrinkTool(pi)` factory closure (it is NOT an
 * execute argument — checkpoint.ts precedent). `toolCallId` (the FIRST execute arg) is UNUSED — the target
 * is explicit (GOTCHA #2; named `_toolCallId`).
 */
async function shrinkExecute(
  pi: ExtensionAPI,
  _toolCallId: string,
  params: ShrinkArgs,
  _signal: AbortSignal | undefined,
  _onUpdate: unknown,
  ctx: ExtensionContext,
): Promise<AgentToolResult<ShrinkDetails>> {
  try {
    // (1) config (spec/05 §2 step 1; E14). GOTCHA #10: read getConfig() ONCE. Master switch FIRST
    //     (E14 master-disable), then the sub-feature gate. The master `enabled:false` makes the WHOLE
    //     extension a no-op (context pass-through + nudges no-op + tools refuse "Mulligan is disabled").
    const config = getConfig();
    if (!config.enabled) return refusal("Mulligan is disabled"); // E14 master switch
    if (!config.shrink.enabled) return refusal("shrink is disabled");

    // (2) replacement non-empty (spec/05 §2 step 2).
    if (!isNonEmpty(params?.replacement)) return refusal("replacement must be non-empty");

    // (3) structural target validity (spec/05 §2 step 3 — "structurally impossible"; GOTCHA #7).
    //     A non-empty-but-currently-unmatched target is NOT refused here (that is advisory feedback, step 3/4).
    if (!targetIsStructurallyValid(params?.target)) return refusal("target discriminator must be non-empty");

    // (3/4) best-effort yes/no match + PIN the matched entry id (spec/05 §2 step 3 — ADVISORY; never blocks
    //       persistence — GOTCHA #6). resolveTargetEntryId returns the stable ENTRY id of the matched message
    //       (or null). matched = (entryId !== null); the ENTRY id becomes the marker's pinnedEntryId so applyShrink
    //       resolves by identity at filter time (FINDING 3 fix — no moving-target drift). Inner try/catch is
    //       belt-and-suspenders (resolveTargetEntryId already catches → null — E13).
    let entryId: string | null;
    try {
      entryId = resolveTargetEntryId(ctx, params.target);
    } catch {
      entryId = null;
    }
    const matched = entryId !== null;

    // (5) persist (spec/05 §2 step 4; GOTCHA #1 — NO cast, NO leaveNote; ShrinkMarkerInput matches EXACTLY).
    //     pinnedEntryId is included ONLY when the target matched at creation (absent → the filter falls back to live
    //     resolution — backward compat / compaction-robust). A non-matching target STILL persists (E8).
    const markerId = appendShrinkMarker(pi, ctx, {
      target: params.target,
      replacement: params.replacement,
      reason: params.reason,
      ...(entryId ? { pinnedEntryId: entryId } : {}),
    } satisfies ShrinkMarkerInput);

    // (5b) operator echo (spec/05 §2 step 5 — zero context cost; the replacement is NOT in the tool result).
    //      P1.M2.T1.S2: surface a capped copy of the replacement to the operator via ctx.ui.notify so the
    //      human can audit what the model recorded, without the model itself paying context for the echo.
    //      E13: a UI failure must NEVER break the tool — the marker is already persisted (own try/catch).
    try {
      if (ctx.hasUI) {
        const capped = cap(params.replacement, config.shrink.notifyMaxChars);
        ctx.ui.notify(`Shrunk ${describeTarget(params.target)} — replacement:\n<<<\n${capped}\n>>>`, "info");
      }
    } catch {
      // E13: a UI failure must never break the tool — the marker is already persisted.
    }

    // (6) return (spec/05 §2 step 5) — feedback text (yes/no from the best-effort match) + details.
    return {
      content: [{ type: "text", text: feedbackText(matched) }],
      details: { matched, markerId },
    };
  } catch (e) {
    // Shared tool convention: never throw — return a text result describing the failure (GOTCHA #5, E13).
    return refusal(`unexpected error: ${e instanceof Error ? e.message : String(e)}`);
  }
}

// ── Factory: the testable `pi`-injection seam (recommended in the PRP) ───────

/**
 * makeShrinkTool — the tool factory. Captures `pi` (ExtensionAPI) via closure so `shrinkExecute` can call
 * `appendShrinkMarker(pi, ctx, …)` WITHOUT `pi` being an execute argument (the Pi ExtensionAPI is passed to
 * the extension FACTORY in src/index.ts, not to each tool's execute()). `defineTool` preserves
 * `ShrinkParams` inference when assigning to a variable (checkpoint.ts precedent).
 *
 * index.ts (P1.M7.T1.S1) will do: `pi.registerTool(makeShrinkTool(pi));`.
 * Unit tests do: `const tool = makeShrinkTool(fakePi);`.
 */
export function makeShrinkTool(pi: ExtensionAPI): ToolDefinition<typeof ShrinkParams, ShrinkDetails> {
  return defineTool({
    name: "mulligan_shrink",
    label: "Mulligan Shrink",
    description: SHRINK_DESC, // spec/05 §5 VERBATIM
    parameters: ShrinkParams,
    async execute(toolCallId, params, signal, onUpdate, ctx) {
      return shrinkExecute(pi, toolCallId, params, signal, onUpdate, ctx); // pi captured via closure
    },
  });
}